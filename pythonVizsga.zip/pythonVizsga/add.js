function sendPost(){
    const data = JSON.stringify({
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        town:document.getElementById("town").value,
        town_id:document.getElementById("town_id").value,
        birth_date:document.getElementById("birth_date").value


      });
      
      navigator.sendBeacon('http://127.0.0.1:5000/savedetails/', data);
      console.log(data);
    }